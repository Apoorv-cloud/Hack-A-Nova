package com.tika.app2.Selections;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.tika.app2.R;

public class PregActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preg);
    }
}
